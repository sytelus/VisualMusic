Visual Music 1.1

Please click on the Visual Music.chm file which contains complete documentation. Microsoft Internet Explorer 4.0 will install the viewer for .chm files.

Visual Music lets you play 128 instruments on your PC including Flute, Bagpiper and even whistle! You can even record what you are playing, edit it and save it in a file. If you not expert at playing synthesiser keyboard, it provides you a easy to use scripting language to create music just by telling what key in which instrument you want to play for how much time!

Visit Visual Music's home page at http://i.am/vmusic

Visual Music is designed and developed by,
Shital Shah.
Email: shital_s@usa.net
Homepage: http://i.am/shital

�Shital Shah, 25 July 1999.
This program is freeware. Source code available upon request. 